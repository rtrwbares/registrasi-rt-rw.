PAKET APLIKASI REGISTRASI KEPENDUDUKAN RT/RW

ISI PAKET
- index.html          Aplikasi browser, responsif untuk HP dan komputer.
- supabase_setup.sql  Struktur database, aturan akses, dan bucket foto.
- README.txt          Panduan pemasangan.

KONFIGURASI
Project URL dan publishable key Supabase sudah diisikan pada index.html:
Project URL: https://qnwjyvunsuizxjccmfzd.supabase.co
Publishable key: sb_publishable_vsCXxYSFcXL_dGt1JzuwKA_qA3nW6ap

LANGKAH PENGGUNAAN
1. Buka project Supabase "Rtrw".
2. Jika SQL belum dijalankan, buka SQL Editor > New query, salin seluruh
   isi supabase_setup.sql, lalu tekan Run. Jika sebelumnya sudah berhasil,
   langkah ini tidak perlu diulang.
3. Buka Authentication > Users > Add user, buat email dan password admin.
   Gunakan email/password itu untuk masuk aplikasi.
4. Unggah index.html ke repository GitHub registrasi-rt-rw (Add file >
   Upload files > Commit changes).
5. Aktifkan GitHub Pages dari Settings > Pages, pilih Deploy from a branch,
   branch main dan folder /(root), lalu Save. Alternatif: deploy repository
   ke Vercel dan ikuti petunjuk Vercel.
6. Buka alamat website dari beberapa HP. Semua HP harus masuk menggunakan
   akun Supabase yang sama atau akun lain yang dibuat di project ini.

FITUR
- Login admin menggunakan Supabase Auth.
- Tambah, edit, cari, dan hapus penduduk.
- Klasifikasi usia dan jenis kelamin di dashboard.
- Foto dokumen dari kamera/galeri HP dan unggah ke Supabase Storage.
- OCR dasar untuk mencoba membaca NIK/nama dari foto; hasil WAJIB dicek
  manual karena kualitas foto/format dokumen dapat memengaruhi akurasi.
- Catatan kelahiran, kematian, datang, dan pindah.
- Ekspor CSV data penduduk dan mutasi.

PENTING TENTANG KEAMANAN DATA
Data NIK, KK, dan foto dokumen adalah data pribadi. Batasi akses website
dan akun hanya untuk petugas yang berwenang. Jangan bagikan URL/foto kepada
publik. Bucket foto pada konfigurasi awal dibuat public agar foto dapat
ditampilkan dengan mudah; untuk penggunaan produksi yang memuat dokumen
identitas, sebaiknya ubah bucket menjadi private dan gunakan signed URL
serta kebijakan akses yang lebih ketat sebelum memasukkan data asli.
Jangan pernah memasukkan service_role key ke file HTML. Publishable key
memang digunakan di browser; keamanan bergantung pada Auth dan RLS.

Aplikasi memerlukan koneksi internet dan CDN untuk Supabase JS serta OCR.
