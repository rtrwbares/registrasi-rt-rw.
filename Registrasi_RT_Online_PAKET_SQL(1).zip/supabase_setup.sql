-- Jalankan seluruh isi file ini di Supabase > SQL Editor > New query.
create extension if not exists pgcrypto;

create table if not exists public.residents (
  id uuid primary key default gen_random_uuid(),
  nik text not null unique,
  no_kk text,
  nama text not null,
  gender text not null check (gender in ('L','P')),
  birth_date date,
  family_status text,
  alamat text,
  rt_rw text,
  agama text,
  marital_status text,
  job text,
  education text,
  photo_path text,
  photo_url text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.resident_events (
  id uuid primary key default gen_random_uuid(),
  nik text,
  nama text,
  jenis text not null check (jenis in ('Kelahiran','Kematian','Datang','Pindah')),
  tanggal date not null,
  keterangan text,
  created_at timestamptz not null default now()
);

alter table public.residents enable row level security;
alter table public.resident_events enable row level security;

drop policy if exists "Authenticated users can manage residents" on public.residents;
create policy "Authenticated users can manage residents"
on public.residents for all to authenticated
using (true) with check (true);

drop policy if exists "Authenticated users can manage resident events" on public.resident_events;
create policy "Authenticated users can manage resident events"
on public.resident_events for all to authenticated
using (true) with check (true);

insert into storage.buckets (id, name, public)
values ('resident-documents', 'resident-documents', true)
on conflict (id) do update set public = true;

drop policy if exists "Authenticated users can upload resident documents" on storage.objects;
create policy "Authenticated users can upload resident documents"
on storage.objects for insert to authenticated
with check (bucket_id = 'resident-documents');

drop policy if exists "Authenticated users can update resident documents" on storage.objects;
create policy "Authenticated users can update resident documents"
on storage.objects for update to authenticated
using (bucket_id = 'resident-documents') with check (bucket_id = 'resident-documents');

drop policy if exists "Authenticated users can delete resident documents" on storage.objects;
create policy "Authenticated users can delete resident documents"
on storage.objects for delete to authenticated
using (bucket_id = 'resident-documents');

-- Catatan: tabel hanya dapat diakses setelah login. Buat akun admin di
-- Supabase Dashboard > Authentication > Users > Add user.
